window.addEventListener('load', function(){
    let colocarElementos = document.getElementById("colocarElementos");
    let contenedor = document.createElement('div');


    
    let imglogo = document.createElement('img');
    imglogo.id = "idlogo";
    imglogo.classList.add("Imagenlogo");
    imglogo.alt = "Logo";
    imglogo.src = "img/logo.jpg"; 
    contenedor.appendChild(imglogo);
    
    let Menu = [
        { id: 0, Texto: "Inicio", link: "index.html" },
        { id: 1, Texto: "Nosotros", link: "nosotros.html" },
        { id: 2, Texto: "Servicios", link: "servicios.html" },
        { id: 3, Texto: "Contacto", link: "contacto.html" },
    ];

    let menuContainer = document.createElement('div');
    menuContainer.id="menuContainer";

    Menu.forEach(item => {
        const link = document.createElement("a");
        link.href = item.link;
        link.textContent = item.Texto;

        menuContainer.appendChild(link);
        contenedor.appendChild(menuContainer);
    });


    let informacion1 = [
        { id: 0, titulo: "titular", imagen: "img/imagen1.jpg" , descipcion: "Lorem ipsum dolor sit amet, consectetur adipisci elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."}
    ];

    let imagenYDescripcion1 = document.createElement('div');
    imagenYDescripcion1.id="imagenYDescripcion1";

        
        
        let img1 = document.createElement('img');
        img1.id = `idImagen_${informacion1[0].id}`;
        img1.classList.add(`Imagen_${informacion1[0].id}`);
        img1.alt =`Imagen_${informacion1[0].id}`;
        img1.src = informacion1[0].imagen; 
        imagenYDescripcion1.appendChild(img1);

        
        
        let DescripcionYMasArriba = document.createElement('div');
        DescripcionYMasArriba.id="DescripcionArriba";
        imagenYDescripcion1.appendChild(DescripcionYMasArriba);

            let TituloArriba = document.createElement('h1');
            TituloArriba.id=`tituloArriba_${informacion1[0].id}`;
            TituloArriba.innerHTML=informacion1[0].titulo;
            DescripcionYMasArriba.appendChild(TituloArriba);

            let DescripcionArriba = document.createElement('div');
            DescripcionArriba.id=`DescripcionArriba_${informacion1[0].id}`;
            DescripcionArriba.innerHTML=informacion1[0].descipcion;
            DescripcionYMasArriba.appendChild(DescripcionArriba);

            let BotonVerMas = document.createElement('input');
            BotonVerMas.id = "DescripcionArriba";
            BotonVerMas.type = "button"; 
            BotonVerMas.value = "Ver más"; 
            DescripcionYMasArriba.appendChild(BotonVerMas);
            

    contenedor.appendChild(imagenYDescripcion1);
     
    

    let informacion2 = [
        { id: 0, titulo: "Este es el titular de la sección 2", imagen: "img/image.png" , descipcion: "Montañas"}
    ];


        let TituloSeccion2 = document.createElement('h2');
        TituloSeccion2.id="DescripcionArriba";
        TituloSeccion2.innerHTML="Este es el titular de la sección 2";
        contenedor.appendChild(TituloSeccion2);

        
        let img2 = document.createElement('img');
        img2.id = `idFoto_${informacion2[0].id}`;
        img2.classList.add(`idFoto_${informacion2[0].id}`);
        img2.alt = informacion2[0].descipcion;
        img2.src = informacion2[0].imagen; 
        contenedor.appendChild(img2);






        
        let viajes = [
            { id: 0, titulo: "Viaje 1", imagen: "img/viaje1.jpg" },
            { id: 1, titulo: "Viaje 2", imagen: "img/viaje2.jpeg" },
            { id: 2, titulo: "Viaje 3", imagen: "img/viaje3.jpg" }
        ];
        
        const viajesdiv = document.createElement("div");
        viajesdiv.classList.add("viajediv");
        contenedor.appendChild(viajesdiv);
        
        viajes.forEach(item=> {
            
            const viajeIndividual = document.createElement("div");
            viajeIndividual.classList.add("viajeIndividual");
            viajeIndividual.id = `viaje_${item.id}`;

            let imgViaje = document.createElement('img');
            imgViaje.id = `foto_viaje_${item.id}`;
            imgViaje.classList.add("ImagenViaje");
            imgViaje.alt = item.titulo;
            imgViaje.src = item.imagen; 
            
            const Tituloviaje= document.createElement("h3");
            Tituloviaje.innerHTML=item.titulo;


            let BotonComprar = document.createElement('input');
            BotonComprar.id = `BotonComprar_${item.id}`;
            BotonComprar.type = "button";
            BotonComprar.value = "Comprar";
            imagenYDescripcion1.appendChild(BotonVerMas);




            viajeIndividual.appendChild(imgViaje);
            viajeIndividual.appendChild(Tituloviaje);
            viajeIndividual.appendChild(BotonComprar);
            viajesdiv.appendChild(viajeIndividual);
        });
        
        
        colocarElementos.appendChild(contenedor);
        
})