const primerPlato = document.getElementById('primer-plato');
const segundoPlato = document.getElementById('segundo-plato');
const postre = document.getElementById('postre');
const descuento = document.getElementById('descuento');
const calcularBtn = document.getElementById('calcular');
const totalDiv = document.getElementById('total');

const precios = {
    lentejas: 3,
    calabaza: 2,
    pollo: 4,
    lubina: 5,
    flan: 1,
    arroz: 2
};

const imagenes = {
    lentejas: 'img/lentejas-con-chorizo.jpg',
    calabaza: 'img/crema_de_calabaza.jpg',
    pollo: 'img/escalope_de_pollo.jpg',
    lubina: 'img/lubina_al_horno.jpg',
    flan: 'img/flan_de_huevo.jpg',
    arroz: 'img/arroz_con_leche.jpg'
};

primerPlato.addEventListener('change', mostrarImagen);
segundoPlato.addEventListener('change', mostrarImagen);
postre.addEventListener('change', mostrarImagen);

function mostrarImagen() {
    const platoSeleccionado = this.value;
    const tipoPlato = this.id; 
    const imagen = document.querySelector(`img[data-plato="${tipoPlato}"]`);
    
    if (imagen) {
        imagen.src = imagenes[platoSeleccionado];
    }
}

calcularBtn.addEventListener('click', () => {
    let total = precios[primerPlato.value] + precios[segundoPlato.value] + precios[postre.value];
    if (descuento.checked) {
        total *= 0.9;
    }
    totalDiv.textContent = `Total: ${total.toFixed(2)} euros`;
});
