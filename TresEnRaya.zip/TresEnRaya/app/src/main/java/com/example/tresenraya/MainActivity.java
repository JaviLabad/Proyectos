package com.example.tresenraya;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private boolean turnoJugador1 = true; // True para X, False para O
    private Button[][] botones;
    private int tamanoTablero = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botones = new Button[tamanoTablero][tamanoTablero];
        TableLayout tablero = findViewById(R.id.tablero);

        for (int i = 0; i < tamanoTablero; i++) {
            TableRow fila = (TableRow) tablero.getChildAt(i);
            for (int j = 0; j < tamanoTablero; j++) {
                botones[i][j] = (Button) fila.getChildAt(j);
                botones[i][j].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (((Button) v).getText().toString().equals("")) {
                            if (turnoJugador1) {
                                ((Button) v).setText("X");
                            } else {
                                ((Button) v).setText("O");
                            }
                            turnoJugador1 = !turnoJugador1;
                            comprobarGanador();
                        }
                    }
                });
            }
        }

        Button jugarButton = findViewById(R.id.jugarButton);
        jugarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comprobarGanador();
            }
        });

        Button reiniciarButton = findViewById(R.id.reiniciarButton);
        reiniciarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reiniciarTablero();
            }
        });
    }

    private void comprobarGanador() {
        // Comprobar filas
        for (int i = 0; i < tamanoTablero; i++) {
            if (botones[i][0].getText().toString().equals(botones[i][1].getText().toString()) &&
                    botones[i][0].getText().toString().equals(botones[i][2].getText().toString()) &&
                    !botones[i][0].getText().toString().equals("")) {
                mostrarGanador(botones[i][0].getText().toString());
                return;
            }
        }

        // Comprobar columnas
        for (int j = 0; j < tamanoTablero; j++) {
            if (botones[0][j].getText().toString().equals(botones[1][j].getText().toString()) &&
                    botones[0][j].getText().toString().equals(botones[2][j].getText().toString()) &&
                    !botones[0][j].getText().toString().equals("")) {
                mostrarGanador(botones[0][j].getText().toString());
                return;
            }
        }

        // Comprobar diagonales
        if (botones[0][0].getText().toString().equals(botones[1][1].getText().toString()) &&
                botones[0][0].getText().toString().equals(botones[2][2].getText().toString()) &&
                !botones[0][0].getText().toString().equals("")) {
            mostrarGanador(botones[0][0].getText().toString());
            return;
        }

        if (botones[0][2].getText().toString().equals(botones[1][1].getText().toString()) &&
                botones[0][2].getText().toString().equals(botones[2][0].getText().toString()) &&
                !botones[0][2].getText().toString().equals("")) {
            mostrarGanador(botones[0][2].getText().toString());
            return;
        }

        // Comprobar si hay empate
        boolean empate = true;
        for (int i = 0; i < tamanoTablero; i++) {
            for (int j = 0; j < tamanoTablero; j++) {
                if (botones[i][j].getText().toString().equals("")) {
                    empate = false;
                    break;
                }
            }
        }
        if (empate) {
            Toast.makeText(this, "¡Empate!", Toast.LENGTH_SHORT).show();
        }
    }

    private void mostrarGanador(String ganador) {
        Toast.makeText(this, "¡" + ganador + " ha ganado!", Toast.LENGTH_SHORT).show();
    }

    private void reiniciarTablero() {
        for (int i = 0; i < tamanoTablero; i++) {
            for (int j = 0; j < tamanoTablero; j++) {
                botones[i][j].setText("");
            }
        }
        turnoJugador1 = true;
    }
}
