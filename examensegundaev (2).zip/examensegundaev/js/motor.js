document.getElementById(b1).addEventListener("click", function() 
{
    alert("hola");
});
